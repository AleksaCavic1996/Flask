from flask import Flask, render_template,redirect, url_for, request, session
from pymongo import MongoClient
from bson import ObjectId
from datetime import datetime
import hashlib
import time

import mysql.connector
app = Flask(__name__)
app.config['SECRET_KEY'] = 'januar2021'
mydb = mysql.connector.connect(
	host="localhost",
	user="root",
	password="",
	database="februar2021"
    )
@app.route('/')
@app.route('/index')
def index():
	return render_template('index.html')

@app.route('/register', methods = ['POST', 'GET'])
def register():
	if request.method == 'GET':
		return render_template('register.html')
	
	username = request.form['username']
	email = request.form['email']
	password = request.form['password']
	cp = request.form['cp']
	godina = request.form['godina']
	jmbg = request.form['jmbg']

	mc = mydb.cursor()
	mc.execute(f"SELECT * FROM korisnici WHERE username = '{username}'")
	rez = mc.fetchall()
	
	if len(rez) > 0:
		return "Korisnik sa tim username vec postoji"

	if password != cp:
		return "Lozinke se ne poklapaju"
	
	if len(jmbg) != 13:
		return "JMBG mora da ima 13 cifara"

	mc = mydb.cursor()
	mc.execute(f"INSERT INTO korisnici VALUES (null, '{username}', '{password}', '{email}', {godina}, '{jmbg}')")
	mydb.commit()

	return redirect(url_for('show_all'))

@app.route('/login', methods = ['POST', 'GET'])
def login():
	if request.method == 'GET':
		return render_template('login.html')
	if 'username' in session:
		return "vec ste ulogovani"

	username = request.form['username']
	password = request.form['password']

	mc = mydb.cursor()
	mc.execute(f"SELECT * FROM korisnici WHERE username = '{username}'")
	rez = mc.fetchall()

	if len(rez) == 0:
		return "Korisnik sa tim username ne postoji"

	if rez[0][2] != password:
		return "Sifre se ne poklapaju"
	
	session['username']= username
	return redirect(url_for('show_all'))

@app.route('/logout')
def logout():
	if 'username' not in session:
		redirect(url_for('show_all'))
	session.pop('username', None)
	return redirect(url_for('login'))

@app.route('/update/<username>', methods = ['POST', 'GET'])
def update(username):
	if request.method == 'GET':
		mc = mydb.cursor()
		mc.execute(f"SELECT * FROM korisnici WHERE username = '{username}'")
		rez = mc.fetchall()
		return render_template('update.html',korisnik = rez[0])



	email = request.form['email']
	password = request.form['password']
	cp = request.form['cp']
	godina = request.form['godina']

	if password != cp:
		return "Sifre se ne poklapaju"
		
	mc = mydb.cursor()
	mc.execute(f"UPDATE korisnici SET email = '{email}', password = '{password}', godina = '{godina}' WHERE username = '{username}'")
	mydb.commit()

	return redirect(url_for('show_all'))




@app.route('/delete/<username>')
def delete(username):
	if 'username' not in session:
		return redirect(url_for('login'))
	mc = mydb.cursor()
	mc.execute(f"DELETE FROM korisnici WHERE username = '{username}'")
	mydb.commit()
	
	return redirect(url_for('show_all'))


@app.route('/show_all')
def show_all():

	mc = mydb.cursor()
	mc.execute(f"SELECT * FROM korisnici")
	rez = mc.fetchall()

	if 'username' in session:
		return render_template('show_all.html', svi_korisnici = rez, ulogovan = True)
	return render_template('show_all.html', svi_korisnici = rez, ulogovan = False)

@app.route('/show_year/<year>')
def show_year(year):

	mc = mydb.cursor()
	mc.execute(f"SELECT * FROM korisnici WHERE godina = '{year}'")
	rez= fetchall()

	if 'username' in session:
		return render_template('show_all.html', svi_korisnici = rez, ulogovan = True)
	return render_template('show_all.html', svi_korisnici = rez, ulogovan = False)













if __name__ == '__main__':
	app.run(debug=True)



